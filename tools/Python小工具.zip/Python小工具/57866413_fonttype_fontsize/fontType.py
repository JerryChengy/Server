import os
uixPath = "D:/xjrpg/Resource/2D/ios/uix/"
uixs = os.listdir(uixPath)

sumS = [[0]*2 for i in range(9)]

for uix in uixs:
    print uix
    fpath = uixPath + uix
    lines = open(fpath,"r").readlines()
    for line in lines:
        line = line.strip(" ")
        if(line.__contains__("<ZJUI")):
            temps = line.split(" ")
            pos = line.find("<ZJUI")
            strtype = temps[0][6:len(temps[0])]
            #only for the type of TextField or QHTML
            if(strtype == 'TextField' or strtype == 'QHTML'):
                pos_s = line.find('size')
                if(pos_s != -1):
                    if(line[pos_s+6] != '{'):
                        size = int(line[pos_s+6:pos_s+8])
                else:
                    size = int(22)
                pos_t = line.find('fontType')
                if(pos_t != -1):
                    type = int(line[pos_t + 10:pos_t + 11])
                else:
                    type = int(0)
                size = (size - 18)/2
                if(size<0):
                    size = 0;
                if(size > 8):
                    size = 8
                if(type !=0 and type != 1):
                    type = 0
                sumS[size][type] = sumS[size][type] + 1
for i in range(9):
    for j in range(2):
        print (i+9)*2,j,sumS[i][j]