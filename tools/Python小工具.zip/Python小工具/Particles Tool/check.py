import os
guding = "D:/xjrpg/Resource/2D/ios/actors/particles/"
path = open("only.txt",r);
lines = path.readlines()
for line in lines:
    line = line.strip("\n")
    if(os.path.exists(guding+line)):
        continue
    else:
        print line