import os
import msvcrt
mydir = "../../2D/ios/particles"
print 'Waiting....'
xmlfiles = []
for root,dirs,files in os.walk(mydir):
    for file in files:
        xmlfiles.append(os.path.join(root,file))
out = []
names = []
outfile = open("1.txt","w")
for xml in xmlfiles:
    lines = (open(xml,"r")).readlines()
    for line in lines:
        temps = line.split(' ')
        for temp in temps:
            if(temp.find('fileName') != -1):
                pos1 = temp.find('X')
                pos2 = temp.find('png')
                if(pos1 + pos2 > 0):
                    nametmp = temp[pos1:pos2] + 'png'
                    names.append(os.path.basename(nametmp))
                    outtmp = os.path.basename(xml) + ' ' + os.path.basename(nametmp);
                    if(len(out) == 0):
                        out.append(outtmp)
                    else:
                        if(outtmp != out[len(out)-1]):
                            out.append(outtmp)

names = set(names)
for eachname in names:
    ltmp = []
    for eachout in out:
        if(eachout.endswith(' ' + eachname)):
            ltmp.append(eachname + ' '+ eachout[:eachout.rfind(' ')])
            del eachout
    ltmp = set(ltmp)
    for eachl in ltmp:
        outfile.write(eachl + "\n")

outfile.close()
print "Please press any key to continue......"
ord(msvcrt.getch())