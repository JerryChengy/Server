import os
file = open("out1.txt","r")
lines = file.readlines()
data0 = []
data1 = []
data2 = []
yingshe = []
for line in lines:
    line = line.strip("\n")
    pos = line.find(" ")
    data0.append(line[:pos])
    data1.append(line[pos+1:])

temp = data0[0]
j = 0
data2.append(0)
yingshe.append(data0[0])
for i in range(len(data0)):
    if(data0[i] == temp):
        data2[j] = data2[j] + 1
    else:
        j = j + 1
        data2.append(1)
        temp = data0[i]
        yingshe.append(temp)

j = 0;
temp = data0[0]
out_sort = open("out_sort.txt","w")
for i in range(len(data0)):
    if(data0[i] == temp):
        strdata = data0[i] + "\t" + data1[i] + "\t" + str(data2[j]) + "\n"
    else:
        temp = data0[i]
        j = j + 1
        strdata = data0[i] + "\t" + data1[i] + "\t" + str(data2[j]) + "\n"
    print strdata
    out_sort.write(strdata)
out_sort.close()