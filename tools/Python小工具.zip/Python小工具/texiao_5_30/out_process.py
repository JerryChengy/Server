import os
file = open("outss.txt","r")
lines = file.readlines();

datas = []
for line in lines:
    datas.append(line.strip("\n"))
outs = []
temp = ''
for i in range(len(datas)):
    ti = datas[i].split("\t")
    if(ti[0] == temp):
        outs.append("\t\t"+ti[2])
    else:
        outs.append(datas[i])
        temp = ti[0]
outfile = open("resultss.txt","w")
for each in outs:
    outfile.write(each+"\n")