import os
#story=57797017
idpath = "C:/xjrpg/win32/id.txt"
hashpath = "C:/xjrpg/win32/hashkey.txt"
imgpath = "D:/xjrpg/Resource/Tools/1.txt"
id_file = open(idpath,"r")
ids = id_file.readlines()
hash_file = open(hashpath,"r")
hashs = hash_file.readlines()
img_file = open(imgpath,"r")
imgs = img_file.readlines()

ptxs = []
keys = []
pngs = []
xmls = []

#process the hashes before
for hash in hashs:
    temp = hash.split(';')
    temp_0 = os.path.basename(temp[0])
    ptxs.append(temp_0)
    temp_1s = temp[1].split(' ')
    temp_13 = temp_1s[3]
    keys.append(temp_13)

#process the 1.txt before
for img in imgs:
    img = img.strip("\n")
    temp = img.split(' ')
    pngs.append(temp[0])
    xmls.append(temp[1])
outfile = open("outss.txt","w")
#process the id
for id in ids:
    id = id.strip("\n")
    for i in range(len(keys)):
        if(id == keys[i]):
            for j in range(len(pngs)):
                if(ptxs[i].strip("ptx") == xmls[j].strip("xml")):
                    outfile.write(id+'\t'+ptxs[i]+'\t'+pngs[j]+"\n")
                    print id+'\t'+ptxs[i]+'\t'+pngs[j]
            break

#locate the images that the ptx contains