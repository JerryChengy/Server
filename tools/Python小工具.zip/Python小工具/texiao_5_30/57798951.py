# coding=utf-8
import os
import ctypes
import sys

#print "0 EtcSceneTexturedb.xml"
#print "1 PvrSceneTexturedb.xml"
#print "2 EtcTexturedb.xml"
#print "3 PvrSceneTexturedb.xml"
#print "4 All"
#print "Please input the xml number:"
#while 1:
#    s = input("Enter your input:")
#    if(s < 5 and s > -1):
#        break
s = 4
xmlpath = ["X:/EtcSceneTexturedb.xml","X:/PvrSceneTexturedb.xml","X:/EtcTexturedb.xml","X:/Texturedb.xml"]
dirpath = ["X:/etcscene/","X:/pvrscene/","X:/etc/","X:/pvr/"]

errors = []
all_flag = 0
re = sys.argv[1]
#process the xml file
names = []
if(s == 4):
    all_flag = 4
while(True):
    if(all_flag < 0):
        break
    if(all_flag > 0):
        s = s - 1
    #0:Android   #1:ios
    if(int(re) == 1):
        if(s%2 == 0):
            all_flag = all_flag - 1
            continue;
    if(int(re) == 0):
        if(s%2 == 1):
            all_flag = all_flag - 1
            continue;
    xml_file = open(xmlpath[s],"r")
    xmls = xml_file.readlines()
    dirs = os.listdir(dirpath[s])
    if(s == 0 or s == 1):
        for xml in xmls:
            xml = xml.strip("\n")
            temp = xml.split(" ")
            if(len(temp) < 3):
                continue
            tpath = temp[3].split("\"")[1]
            pathtemp = tpath.split("/")
            if(pathtemp[1] == "scenes"):
                if(pathtemp[len(pathtemp) - 1].endswith("png")):
                    pass
                else:
                    continue
                n_tmp = pathtemp[3][:len( pathtemp[3])-4]
                names.append(pathtemp[2] + '/' +  n_tmp + ".jpg")
                if(os.path.exists(dirpath[s] + pathtemp[2] + '/' +  n_tmp + ".jpg")):
                    continue
                else:
                    errors.append(os.path.basename(xmlpath[s])+" " +xml)
                    #print xml
    else:
        for xml in xmls:
            xml = xml.strip("\n")
            temp = xml.split(" ")
            if(len(temp) < 3):
                continue
            tpath = temp[3].split("\"")[1]
            names.append(tpath)
            if(os.path.exists(dirpath[s] +  '/' +  tpath)):     #xmlpath is not the destination
                continue
            else:
                errors.append(os.path.basename(xmlpath[s])+" " +xml)
                #print xml

    #process the dir
    if(s == 0 or s == 1):
        for dir in dirs:
            if(os.path.isdir(dirpath[s] + '/' + dir)):
                temps = os.listdir(dirpath[s] + '/' + dir)
                for temp in temps:
                    ftemp = dir + '/' + temp
                    flag = 0
                    for name in names:
                        if(ftemp == name):
                            flag = 1
                            break
                    if(flag == 0):
                        errors.append(dirpath[s]+ftemp)
                        #print dirpath[s]+ftemp
    else:
        for dir in dirs:
            flag = 0
            for name in names:
                if(dir == name):
                    flag = 1
                    break
            if(flag == 0):
                #print dirpath[s]+dir
                errors.append(dirpath[s]+dir)
    all_flag = all_flag - 1

errMsg = ''
for i in range(len(errors)):
    errMsg = errMsg + str(i+1)+'.  '+errors[i]+'\n'

if(len(errors) > 0):
    ctypes.windll.user32.MessageBoxW(0,u''+errMsg,u'Error' ,0)
    #tkMessageBox.showinfo(title = '111',message= errMsg)