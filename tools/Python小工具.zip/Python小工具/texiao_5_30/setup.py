from distutils.core import setup
import py2exe
setup(console=["57798951.py"])